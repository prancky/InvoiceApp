export {default} from '@react-native-community/async-storage/jest/async-storage-mock';
