const Colors = {
  White: '#ffffff',
  BgGray: '#F7F7F7',
  Red: '#EB1B23',
  Black: '#231E20',
};

export default Colors;
