export const API_URL = `https://sandbox.101digital.io/`;
export const API_AUTH_KEY = `Basic TGJUZVVFT2RpTEhhZzV4aUxpWDdPQ3ZFbmZNYTpiWVNtbFRBakxsVDJuWEc1SVh2QjNLRDdvVm9h`;
